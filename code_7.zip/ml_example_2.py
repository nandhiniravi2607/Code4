import tslearn
print(tslearn.__version__)